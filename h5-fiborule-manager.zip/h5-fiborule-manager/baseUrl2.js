module.exports = A = () => {
	let proxyObj
	switch (process.env.NODE_ENV) {
		case 'development': // 开发环境代理地址
			proxyObj = {
				'/rule': {
					target: 'http://192.168.1.38:8182/', // 开发环境
					changeOrigin: true, // 是否跨域
					pathRewrite: {
						'^/rule': '/rule'
					},

				},
			}
			break
		case 'A': // A环境
			proxyObj = {
				'/rule': {
					target: 'http://192.168.50.222:8182', // 喻念
					changeOrigin: true, // 是否跨域
					pathRewrite: {
						'^/rule': '/rule'
					}
				}
			}
			break
		case 'B': // B环境
			proxyObj = {
				'/rule': {
					target: 'http://192.168.50.133:8080', // 生产环境
					changeOrigin: true, // 是否跨域
					pathRewrite: {
						'^/rule': '/rule'
					}
				}
			}
			break
		case 'C': // C环境
			proxyObj = {
				'/rule': {
					target: 'http://192.168.50.91:8080', // 生产环境
					changeOrigin: true, // 是否跨域
					pathRewrite: {
						'^/rule': '/rule'
					}
				}
			}
			break
		case 'D': // D环境
			proxyObj = {
				'/rule': {
					target: 'http://192.168.50.226:8080', // 生产环境
					changeOrigin: true, // 是否跨域
					pathRewrite: {
						'^/rule': '/rule'
					}
				}
			}
			break
	}
	return proxyObj
}